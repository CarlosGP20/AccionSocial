<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<link href="css/comunidad.css" rel=stylesheet type="text/css">
<!------ Include the above in your HEAD tag ---------->

<div class="navbar-wrapper">
    <div class="container-fluid">
        <nav class="navbar navbar-fixed-top">
            <div class="container">
                <div class="navbar-header">                   
                    <a class="navbar-brand" href="#"><img src="img/logo.png" class="img-circle" id="logo"></a>
                </div>
                <div id="navbar" class="navbar-collapse collapse">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="#" class="">Inicio</a></li>
                        <li><a href="comunidad">Comunidad</a></li>
                        <li><a href="comunidad">Cobrador</a></li>
                        <li><a href="#">Acerca de</a></li>                        
                        <li><a href="#">Ayuda</a></li>                        
                        
                        
                    </ul>
                    <ul class="nav navbar-nav pull-right">
                        <li><a href="login">Cerrar Sesion</a></li>                        
                    </ul>
                </div>
            </div>
        </nav>
    </div>
</div>


<form class="form-horizontal">
<fieldset>

<!-- Form Name -->
<legend></legend>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="nombre">Nombre</label>  
  <div class="col-md-5">
  <input id="nombre" name="nombre" type="text" placeholder="" class="form-control input-md" required="">
    
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="password">CI</label>  
  <div class="col-md-5">
  <input id="ci" type="text" required name="ci" placeholder="" class="form-control input-md"> 
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="apellido">Dirección</label>  
  <div class="col-md-5">
  <input id="direccion" name="direccion" type="text" placeholder="" class="form-control input-md" required="">
    
  </div>
</div>

<!-- Button -->
<!-- Button -->
<div class="form-group">
  <label class="col-md-4 control-label" for="enviar"></label>
  <div class="col-md-4">
    <button id="enviar" name="enviar" class="btn btn-success">Enviar</button>
  </div>
</div>

</fieldset>
</form>