<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<link href="css/home.css" rel=stylesheet type="text/css">
<!------ Include the above in your HEAD tag ---------->

<div class="navbar-wrapper">
    <div class="container-fluid">
        <nav class="navbar navbar-fixed-top">
            <div class="container">
                <div class="navbar-header">                   
                    <a class="navbar-brand" href="#"><img src="img/logo.png" class="img-circle" id="logo"></a>
                </div>
                <div id="navbar" class="navbar-collapse collapse">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="#" class="">Inicio</a></li>
                        <li><a href="#">Acerca de</a></li>                        
                        <li><a href="#">Ayuda</a></li>                        
                        
                        
                    </ul>
                    <ul class="nav navbar-nav pull-right">
                        <li><a href="login">Iniciar Sesion</a></li>                        
                    </ul>
                </div>
            </div>
        </nav>
    </div>
</div>
<div id="home">
    <div class="container">
        <div>
            <h1 id="titulo1">Sistema de Información y Facturación de Agua Potable Regional</h1>
        </div>
        <div id="cuerpo">
            <img src="img/image1.jpg" id="img1">
        </div>
    </div>
</div>
