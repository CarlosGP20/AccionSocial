<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateDuenoTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('dueno', function (Blueprint $table) {
          $table->increments('dueno_id');
          $table->integer('comunidad_id');
          $table->foreign('comunidad_id')->references('comunidad_id')->on('comunidad');
          $table->string('dueno_ci');
          $table->string('dueno_nombre');
          $table->string('dueno_domicilio');
          $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('dueno');
    }
}
