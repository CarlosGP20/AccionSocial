<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCobradorTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('cobrador', function (Blueprint $table) {
          $table->increments('cobrador_id');
          $table->integer('rol_id');
          $table->foreign('rol_id')->references('rol_id')->on('segrol');
          $table->string('cobrador_nombre');
          $table->string('cobrador_cedula');
          $table->string('cobrador_direccion');
          $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('cobrador');
    }
}
