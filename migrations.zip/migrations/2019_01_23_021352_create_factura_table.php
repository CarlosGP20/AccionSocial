<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateFacturaTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('factura', function (Blueprint $table) {
          $table->increments('factura_id');
          $table->integer('rzs_id');
          $table->foreign('rzs_id')->references('rzs_id')->on('razon_social');
          $table->integer('cobrador_id');
          $table->foreign('cobrador_id')->references('cobrador_id')->on('cobrador');
          $table->integer('lectura_id');
          $table->foreign('lectura_id')->references('lectura_id')->on('lectura');
          $table->date('factura_fecha');
          $table->decimal('factura_valor');
          $table->char('factura_pagada');
          $table->integer('factura_nofactura');
          $table->integer('factura_saldo');
          $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('factura');
    }
}
