<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSegrolTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('segrol', function (Blueprint $table) {
          $table->increments('rol_id');
          $table->integer('cobrador_id');
          $table->foreign('cobrador_id')->references('cobrador_id')->on('cobrador');
          $table->integer('rol_id');
          $table->foreign('rol_id')->references('rol_id')->on('segrol');
          $table->integer('rzs_ruc');
          $table->string('rzs_telefono');
          $table->string('rzs_direccion');
          $table->string('rzs_nombre');
          $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('segrol');
    }
}
