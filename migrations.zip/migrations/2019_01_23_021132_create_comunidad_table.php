<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateComunidadTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('comunidad', function (Blueprint $table) {
            $table->increments('comunidad_id');
            $table->integer('par_id');
            $table->foreign('par_id')->references('par_id')->on('parametro');
            $table->integer('dueno_id');
            $table->foreign('dueno_id')->references('dueno_id')->on('dueno');
            $table->string('comunidad_nombre');
            $table->decimal('comunidad_valor_m3');
            $table->decimal('comunidad_descuento');
            $table->decimal('comunidad_multa');
            $table->string('comunidad_email');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('comunidad');
    }
}
