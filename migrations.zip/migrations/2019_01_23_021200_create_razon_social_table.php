<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateRazonSocialTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('razon_social', function (Blueprint $table) {
          $table->increments('rzs_id');
          $table->integer('comunidad_id');
          $table->foreign('comunidad_id')->references('comunidad_id')->on('comunidad');
          $table->integer('rol_id');
          $table->foreign('rol_id')->references('rol_id')->on('segrol');
          $table->integer('rzs_ruc');
          $table->string('rzs_telefono');
          $table->string('rzs_direccion');
          $table->string('rzs_nombre');
          $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('razon_social');
    }
}
