<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateLoteTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('lote', function (Blueprint $table) {
          $table->increments('lote_id');
          $table->integer('dueno_id');
          $table->foreign('dueno_id')->references('dueno_id')->on('dueno');
          $table->integer('comunidad_id');
          $table->foreign('comunidad_id')->references('comunidad_id')->on('comunidad');
          $table->string('lote_ubicacion');
          $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('lote');
    }
}
