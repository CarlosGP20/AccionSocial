<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSegusuarioTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('segusuario', function (Blueprint $table) {
          $table->increments('usuario_id');
          $table->string('usuario_username');
          $table->string('usuario_nombre');
          $table->string('usuario_email');
          $table->string('usuario_contraseña');
          $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('segusuario');
    }
}
